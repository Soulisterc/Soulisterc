Source for sildurs shaders website built with hexo, using the next theme as a base.
